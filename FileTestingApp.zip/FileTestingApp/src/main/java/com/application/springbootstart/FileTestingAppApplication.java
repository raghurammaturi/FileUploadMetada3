package com.application.springbootstart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileTestingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileTestingAppApplication.class, args);
	}
}
